package com.sena.ubicacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UbicacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
